# hand_sgine > 2023-10-14 8:41pm
https://universe.roboflow.com/dibyajyoti-mohanty-eqerk/hand_sgine

Provided by a Roboflow user
License: CC BY 4.0

