# cars truck models > 2023-03-16 6:23pm
https://universe.roboflow.com/jiangnan-university-eregf/cars-truck-models

Provided by a Roboflow user
License: CC BY 4.0

